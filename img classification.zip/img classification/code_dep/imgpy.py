import os
import cv2
import imghdr
import numpy as np
from matplotlib import pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dense, Flatten, Dropout
from tensorflow.keras.models import load_model
from tensorflow.keras.metrics import Precision, Recall, BinaryAccuracy
#pip list
# Directory containing the images


# Allowed image extensions
image_exts = ['jpeg', 'jpg', 'bmp', 'png']

# Filter out invalid images
for folder_path in folder_paths:
    for img_class in os.listdir(folder_path):
        class_path = os.path.join(folder_path, img_class)
        if os.path.isdir(class_path):
            for image in os.listdir(class_path):
                image_path = os.path.join(class_path, image)
                try:
                    img = cv2.imread(image_path)
                    tip = imghdr.what(image_path)
                    if tip not in image_exts:
                        print(f'Image not in extension list: {image_path}')
                        os.remove(image_path)
                except Exception as e:
                    print(f'Issue with image {image_path}: {e}')

# Load dataset
data = tf.keras.utils.image_dataset_from_directory('C:/Users/Ravi/Downloads/New projects/img', image_size=(256, 256), batch_size=32)

# Split the data
train_size = int(0.7 * len(data))
val_size = int(0.2 * len(data))
test_size = int(0.1 * len(data))

train_data = data.take(train_size)
val_data = data.skip(train_size).take(val_size)
test_data = data.skip(train_size + val_size).take(test_size)

# Normalize the data
train_data = train_data.map(lambda x, y: (x / 255, y))
val_data = val_data.map(lambda x, y: (x / 255, y))
test_data = test_data.map(lambda x, y: (x / 255, y))

# Build the CNN model
model = Sequential([
    Conv2D(16, (3, 3), activation='relu', input_shape=(256, 256, 3)),
    MaxPooling2D(),
    Conv2D(32, (3, 3), activation='relu'),
    MaxPooling2D(),
    Conv2D(16, (3, 3), activation='relu'),
    MaxPooling2D(),
    Flatten(),
    Dense(256, activation='relu'),
    Dense(3, activation='softmax')  # Changed to 3 for three classes
])

# Compile the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Train the model
logdir = 'logs'
tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir=logdir)
history = model.fit(train_data, epochs=20, validation_data=val_data, callbacks=[tensorboard_callback])

# Plot the training history
fig = plt.figure()
plt.plot(history.history['loss'], color='teal', label='loss')
plt.plot(history.history['val_loss'], color='orange', label='val_loss')
fig.suptitle('Loss', fontsize=20)
plt.legend(loc="upper left")
plt.show()

fig = plt.figure()
plt.plot(history.history['accuracy'], color='teal', label='accuracy')
plt.plot(history.history['val_accuracy'], color='orange', label='val_accuracy')
fig.suptitle('Accuracy', fontsize=20)
plt.legend(loc="upper left")
plt.show()

from tensorflow.keras.metrics import Precision, Recall, Accuracy
# Evaluate the model
pre = Precision()
re = Recall()
acc = Accuracy()

for batch in test_data.as_numpy_iterator():
    X, y = batch
    yhat = model.predict(X)
    pre.update_state(y, yhat)
    re.update_state(y, yhat)
    acc.update_state(y, yhat)

print(pre.result(), re.result(), acc.result())
import cv2

img=cv2.imread('C:/Users/Ravi/Downloads/New projects/img/safe/anime images_2.png')
plt.imshow(img)
plt.show()


resize = tf.image.resize(img, (256,256))
plt.imshow(resize.numpy().astype(int))
plt.show()


yhat = model.predict(np.expand_dims(resize/255, 0))

# Assuming yhat is a probability prediction array
threshold = 0.5  # Set your threshold value here

# Check if any probability exceeds the threshold
if np.any(yhat > threshold):
    print(f'Predicted class is adult')
elif np.any(yhat < (1 - threshold)):
    print(f'Predicted class is safe')
else:
    print(f'Predicted class is viol')
    
from tensorflow.keras.models import load_model
model.save(os.path.join('models','imageclassifier.h5'))

new_model = load_model(os.path.join('models', 'imageclassifier.h5'))
new_model.predict(np.expand_dims(resize/255, 0))
