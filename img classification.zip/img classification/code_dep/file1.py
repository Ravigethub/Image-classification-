import os
from PIL import Image

def get_images_in_folder(folder_path):
    """
    Returns a list of image files in the specified folder.

    Parameters:
    folder_path (str): The path to the folder to search for images.

    Returns:
    list: A list of image file paths.
    """
    image_files = []

    # Check if the folder path exists
    if not os.path.exists(folder_path):
        print(f"The folder path '{folder_path}' does not exist.")
        return image_files

    # Iterate over all files in the folder
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        print(f"Checking file: {file_path}")

        try:
            # Attempt to open the file as an image
            with Image.open(file_path) as img:
                print(f"Identified as image: {file_path}")
                # If successful, append to the list
                image_files.append(file_path)
        except (IOError, OSError):
            print(f"Not an image: {file_path}")
            # If the file is not an image, skip it
            continue

    return image_files

def get_images_in_folders(folder_paths):
    """
    Returns a list of image files in the specified folders.

    Parameters:
    folder_paths (list): A list of folder paths to search for images.

    Returns:
    list: A combined list of image file paths from all specified folders.
    """
    all_images = []
    for folder_path in folder_paths:
        print(f"Processing folder: {folder_path}")
        images = get_images_in_folder(folder_path)
        all_images.extend(images)
    return all_images

