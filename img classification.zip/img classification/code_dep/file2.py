#from file1 import *

# Example usage
folder_paths = [
    "C:/Users/Ravi/Downloads/New projects/img/adult",
    "C:/Users/Ravi/Downloads/New projects/img/safe",
    "C:/Users/Ravi/Downloads/New projects/img/violent"
]

df = get_images_in_folders(folder_paths)
#print("Images found:", images)
