
import streamlit as st
import tensorflow as tf
import numpy as np
import cv2
from tensorflow.keras.models import load_model

# Load the model
model = load_model('models/imageclassifier.h5')


# Function to preprocess images
def preprocess_image(image):
    # Resize and normalize the image
    resized_image = cv2.resize(image, (256, 256))
    normalized_image = resized_image / 255.0
    return normalized_image

# Function to make predictions
# Function to make predictions
def predict(image):
    processed_image = preprocess_image(image)
    prediction = model.predict(np.expand_dims(processed_image, 0))
    class_label = np.argmax(prediction)  # Get the index of the class with the highest probability
    if class_label == 0:
        return "Safe"
    elif class_label == 1:
        return "Adult"
    else:
        return "Violent"
# Define the Streamlit app
def main():
    st.title('Image Classifier')
    st.sidebar.title('Upload Image')

    uploaded_image = st.sidebar.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

    if uploaded_image is not None:
        image = np.array(uploaded_image)
        st.image(image, caption='Uploaded Image', use_column_width=True)
        prediction = predict(image)
        st.write('Prediction:', prediction)

# Run the app
if __name__ == '__main__':
    main()
    
